.. include:: ../../README.rst

.. toctree::

   Slicefinder
