from .slicefinder import Slicefinder

__all__ = ("Slicefinder",)