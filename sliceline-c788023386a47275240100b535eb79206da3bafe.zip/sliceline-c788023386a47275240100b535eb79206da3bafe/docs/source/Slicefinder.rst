Slicefinder
===========

.. autoclass:: sliceline.Slicefinder
